import { lazy, Suspense, useState, useMemo } from 'react';
import {
  Link,
  Navigate,
  Route,
  Routes,
  useLocation,
  useSearchParams,
} from 'react-router-dom';
import {
  BookOpen,
  FileText,
  GraduationCap,
  Menu,
  NotebookTabs,
  Search,
  Star,
  X,
} from 'lucide-react';
import { useAuth } from './AuthContext.jsx';
import { useNotes } from './hooks/useNotes.js';
import RouteSpinner from './components/RouteSpinner.jsx';
import { LoadingScreen } from './components/ui.jsx';
import { BookmarkButton } from './components/BookmarkButton.jsx';

const LoginPage = lazy(() => import('./pages/LoginPage.jsx'));
const RegisterPage = lazy(() => import('./pages/RegisterPage.jsx'));
const UploadPage = lazy(() => import('./pages/UploadPage.jsx'));
const DashboardPage = lazy(() => import('./pages/DashboardPage.jsx'));
const LibraryPage = lazy(() => import('./pages/LibraryPage.jsx'));
const CategoriesPage = lazy(() => import('./pages/CategoriesPage.jsx'));
const SppuBranchesPage = lazy(() => import('./pages/SppuBranchesPage.jsx'));
const SemesterSelectionPage = lazy(() => import('./pages/SemesterSelectionPage.jsx'));
const SubjectMarketplacePage = lazy(() => import('./pages/SubjectMarketplacePage.jsx'));
const SubjectPlaceholderPage = lazy(() => import('./pages/SubjectPlaceholderPage.jsx'));
const CatalogueDetailPage = lazy(() => import('./pages/CatalogueDetailPage.jsx'));
const NoteDetailPage = lazy(() => import('./pages/NoteDetailPage.jsx'));
const ContributorProfilePage = lazy(() => import('./pages/ContributorProfilePage.jsx'));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage.jsx'));

const categoryCards = [
  {
    label: 'JEE',
    icon: NotebookTabs,
    to: '/categories',
  },
  {
    label: 'NEET',
    icon: FileText,
    to: '/categories',
  },
  {
    label: 'Engineering',
    icon: GraduationCap,
    to: '/categories',
  },
  {
    label: 'SPPU',
    icon: BookOpen,
    to: '/sppu',
  },
];

function PageSuspense({ label, children }) {
  return <Suspense fallback={<RouteSpinner label={label} />}>{children}</Suspense>;
}

function App() {
  return (
    <div className="min-h-screen text-text-primary">
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route
          path="/categories"
          element={
            <PageSuspense label="Loading categories...">
              <CategoriesPage />
            </PageSuspense>
          }
        />
        <Route
          path="/sppu"
          element={
            <PageSuspense label="Loading SPPU branches...">
              <SppuBranchesPage />
            </PageSuspense>
          }
        />
        <Route
          path="/sppu/:branchSlug/:semesterSlug/:subjectSlug"
          element={
            <PageSuspense label="Loading subject...">
              <SubjectPlaceholderPage />
            </PageSuspense>
          }
        />
        <Route
          path="/sppu/:branchSlug/:semesterSlug"
          element={
            <PageSuspense label="Loading subjects...">
              <SubjectMarketplacePage />
            </PageSuspense>
          }
        />
        <Route
          path="/sppu/:branchSlug"
          element={
            <PageSuspense label="Loading semesters...">
              <SemesterSelectionPage />
            </PageSuspense>
          }
        />
        <Route
          path="/note/:id"
          element={
            <PageSuspense label="Loading note...">
              <NoteDetailPage />
            </PageSuspense>
          }
        />
        <Route
          path="/contributor/:uid"
          element={
            <PageSuspense label="Loading contributor profile...">
              <ContributorProfilePage />
            </PageSuspense>
          }
        />
        <Route
          path="/sppu/:branchSlug/:semesterSlug/:subjectSlug/:catalogueId"
          element={
            <PageSuspense label="Loading catalogue...">
              <CatalogueDetailPage />
            </PageSuspense>
          }
        />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <PageSuspense label="Loading dashboard...">
                <DashboardPage />
              </PageSuspense>
            </ProtectedRoute>
          }
        />
        <Route
          path="/library"
          element={
            <ProtectedRoute>
              <PageSuspense label="Loading library...">
                <LibraryPage />
              </PageSuspense>
            </ProtectedRoute>
          }
        />
        <Route
          path="/login"
          element={
            <PageSuspense label="Loading login...">
              <LoginPage />
            </PageSuspense>
          }
        />
        <Route
          path="/register"
          element={
            <PageSuspense label="Loading register...">
              <RegisterPage />
            </PageSuspense>
          }
        />
        <Route
          path="/upload"
          element={
            <ProtectedRoute>
              <PageSuspense label="Loading upload...">
                <UploadPage />
              </PageSuspense>
            </ProtectedRoute>
          }
        />
        <Route
          path="*"
          element={
            <PageSuspense label="Loading...">
              <NotFoundPage />
            </PageSuspense>
          }
        />
      </Routes>
    </div>
  );
}

function Navbar() {
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full glass-strong">
      <div className="mx-auto flex w-full max-w-[1200px] items-center justify-between px-[24px] py-4">
        <Link to="/" className="font-display text-xl font-bold text-text-primary hover:text-brand-primary transition-colors" aria-label="StudyVault home">
          StudyVault
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-text-secondary">
          <Link className="transition hover:text-brand-primary hover:text-brand-cyan" to="/sppu">
            Browse
          </Link>
          <Link className="transition hover:text-brand-primary hover:text-brand-cyan" to="/upload">
            Upload
          </Link>
          {user && (
            <Link className="transition hover:text-brand-primary hover:text-brand-cyan" to="/library">
              Library
            </Link>
          )}
          {user && (
            <Link className="transition hover:text-brand-primary hover:text-brand-cyan" to="/dashboard">
              Dashboard
            </Link>
          )}
          {user ? (
            <button
              onClick={logout}
              className="transition hover:text-brand-primary hover:text-brand-cyan"
            >
              Logout
            </button>
          ) : (
            <Link className="transition hover:text-brand-primary hover:text-brand-cyan" to="/login">
              Login
            </Link>
          )}
        </nav>

        <button
          className="md:hidden text-text-secondary hover:text-text-primary transition"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden w-full border-t border-glass glass-strong">
          <nav className="flex flex-col px-[24px] py-4 gap-3 text-text-secondary">
            <Link
              className="transition hover:text-brand-primary hover:text-brand-cyan"
              to="/sppu"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Browse
            </Link>
            <Link
              className="transition hover:text-brand-primary hover:text-brand-cyan"
              to="/upload"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Upload
            </Link>
            {user && (
              <Link
                className="transition hover:text-brand-primary hover:text-brand-cyan"
                to="/library"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Library
              </Link>
            )}
            {user && (
              <Link
                className="transition hover:text-brand-primary hover:text-brand-cyan"
                to="/dashboard"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Dashboard
              </Link>
            )}
            {user ? (
              <button
                onClick={() => {
                  logout();
                  setIsMobileMenuOpen(false);
                }}
                className="text-left transition hover:text-brand-primary hover:text-brand-cyan"
              >
                Logout
              </button>
            ) : (
              <Link
                className="transition hover:text-brand-primary hover:text-brand-cyan"
                to="/login"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Login
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

function HomePage() {
  const [search, setSearch] = useState('');
  const { notes, loading } = useNotes();
  const [searchParams] = useSearchParams();
  const subjectFromUrl = searchParams.get('subject') || '';

  const effectiveSearch = search || subjectFromUrl;
  const filteredNotes = notes.filter((note) => {
    const query = effectiveSearch.trim().toLowerCase();
    if (!query) return false;
    const tags = Array.isArray(note.tags) ? note.tags : [];
    return (
      note.title?.toLowerCase().includes(query) ||
      note.subject?.toLowerCase().includes(query) ||
      note.description?.toLowerCase().includes(query) ||
      tags.some((tag) => tag.toLowerCase().includes(query))
    );
  });

  const topNotes = useMemo(() => {
    return [...notes]
      .filter((n) => Number(n.rating || 0) > 0)
      .sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0))
      .slice(0, 3);
  }, [notes]);

  const topContributors = useMemo(() => {
    const map = new Map();
    notes.forEach((note) => {
      const uid = note.uploadedBy;
      if (!uid) return;
      const existing = map.get(uid) || {
        uid,
        name: note.uploaderName || 'SPPU Student',
        avatar: note.uploaderAvatar || '',
        ratingSum: 0,
        ratingCount: 0,
        noteCount: 0,
        downloadSum: 0,
      };
      existing.noteCount += 1;
      existing.downloadSum += Number(note.downloads || 0);
      existing.ratingSum += Number(note.rating || 0) * Number(note.ratingCount || 0);
      existing.ratingCount += Number(note.ratingCount || 0);
      map.set(uid, existing);
    });
    return Array.from(map.values())
      .map((c) => ({
        ...c,
        rating: c.ratingCount ? (c.ratingSum / c.ratingCount).toFixed(1) : '0.0',
      }))
      .sort((a, b) => b.noteCount - a.noteCount)
      .slice(0, 3);
  }, [notes]);

  return (
    <main className="mx-auto w-full max-w-[1200px] px-5 py-12 sm:px-8">
      <section className="mx-auto flex w-full max-w-[1200px] flex-col items-center px-[24px] pb-12 pt-12">
        <div className="w-full max-w-[700px] text-center">
          <h1 className="font-display text-[2.5rem] font-bold text-text-primary">
            India's student-powered study library
          </h1>
          <p className="mt-3 text-[1rem] text-text-secondary">
            Notes, PYQs and guides from students across schools, colleges and exams
          </p>
        </div>

        <div className="relative mt-8 w-full max-w-[600px]">
          <Search
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-text-muted"
            size={20}
            aria-hidden="true"
          />
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            className="w-full rounded-xl border border-glass bg-bg-surface/80 py-3 pl-[44px] pr-4 text-sm text-text-primary placeholder:text-text-muted outline-none backdrop-blur-sm transition-colors focus:border-brand-primary focus:shadow-brand-glow"
            placeholder="Search notes, subjects, exams..."
            type="search"
          />
        </div>
      </section>

      {search.trim() && (
        <section className="mx-auto w-full max-w-[1200px] px-[24px] pb-12">
          <div className="mb-6">
            <h2 className="text-[14px] font-semibold uppercase tracking-wider text-text-secondary">
              Search Results
            </h2>
            <p className="mt-2 text-sm text-text-muted">
              {filteredNotes.length} result(s) for &ldquo;{search}&rdquo;
            </p>
          </div>

          {loading ? (
            <LoadingState label="Searching notes..." />
          ) : filteredNotes.length > 0 ? (
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {filteredNotes.map((note) => (
                <article
                  key={note.id}
                  className="flex flex-col rounded-xl border border-glass bg-bg-surface/60 p-6 backdrop-blur-sm transition-all duration-200 hover:border-brand-primary/50 hover:shadow-brand-glow hover:-translate-y-1"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <p className="text-[12px] font-medium text-text-muted">
                        {note.uploaderName || 'SPPU Student'}
                      </p>
                      <h3 className="mt-3 text-xl font-semibold leading-snug text-text-primary">
                        {note.title}
                      </h3>
                      <p className="mt-2 text-sm text-text-secondary">
                        {note.subject} &middot; Semester {note.semester}
                      </p>
                    </div>
                    <BookmarkButton noteId={note.id} className="border-glass bg-bg-deep/40" />
                  </div>
                  <div className="mt-4 flex items-center gap-4 text-sm text-text-secondary">
                    <span className="inline-flex items-center gap-1.5">
                      <Star className="text-brand-cyan" size={16} fill="currentColor" aria-hidden="true" />
                      {Number(note.rating || 0).toFixed(1)}
                    </span>
                    <span>{note.downloads || 0} downloads</span>
                  </div>
                  <Link
                    to={`/note/${note.id}`}
                    className="mt-auto inline-flex h-11 items-center justify-center rounded-lg border border-glass-strong bg-brand-primary/10 px-4 text-sm font-medium text-brand-primary transition-all duration-200 hover:bg-brand-primary/20"
                  >
                    View Resource
                  </Link>
                </article>
              ))}
            </div>
          ) : (
            <div className="rounded-xl border border-glass bg-bg-surface/40 p-10 text-center backdrop-blur-sm">
              <p className="text-text-secondary">
                No resources found matching &ldquo;{search}&rdquo;.
              </p>
            </div>
          )}
        </section>
      )}

      <section id="notes" className="mx-auto w-full max-w-[1200px] px-[24px] pb-16">
        <div className="mb-6">
          <h2 className="text-[14px] font-semibold uppercase tracking-wider text-text-secondary">Choose a Category</h2>
          <p className="mt-2 text-sm text-text-muted">Browse study resources by exam, university, or course.</p>
        </div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {categoryCards.map((category) => {
            const Icon = category.icon;

            return (
              <Link
                key={category.label}
                to={category.to}
                className="flex h-[120px] flex-col items-center justify-center rounded-xl border border-glass bg-bg-surface/40 text-center backdrop-blur-sm transition-all duration-200 hover:border-brand-primary/50 hover:shadow-brand-glow hover:-translate-y-1"
              >
                <Icon className="text-brand-cyan" size={24} aria-hidden="true" />
                <span className="mt-3 text-sm font-medium leading-tight text-text-primary">{category.label}</span>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="mx-auto w-full max-w-[1200px] px-[24px] pb-16">
        <div className="mb-6">
          <h2 className="text-[14px] font-semibold uppercase tracking-wider text-text-secondary">Top Resources</h2>
          <p className="mt-2 text-sm text-text-muted">Highest-rated notes uploaded by the student community.</p>
        </div>

        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {topNotes.length > 0 ? (
            topNotes.map((note) => (
              <article
                key={note.id}
                className="flex h-[240px] flex-col rounded-xl border border-glass bg-bg-surface/60 p-6 backdrop-blur-sm transition-all duration-200 hover:border-brand-primary/50 hover:shadow-brand-glow hover:-translate-y-1"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <p className="text-[12px] font-medium text-text-muted">{note.uploaderName || 'SPPU Student'}</p>
                    <h3 className="mt-3 text-xl font-semibold leading-snug text-text-primary">{note.title}</h3>
                  </div>
                  <BookmarkButton noteId={note.id} className="border-glass bg-bg-deep/40" />
                </div>

                <div className="mt-4 flex items-center justify-between gap-4 text-sm text-text-secondary">
                  <span className="inline-flex items-center gap-1.5">
                    <Star className="text-brand-cyan" size={16} fill="currentColor" aria-hidden="true" />
                    {Number(note.rating || 0).toFixed(1)}
                  </span>
                  <span>{note.downloads || 0} downloads</span>
                </div>

                <Link
                  to={`/note/${note.id}`}
                  className="mt-auto inline-flex h-11 items-center justify-center rounded-lg border border-glass-strong bg-brand-primary/10 px-4 text-sm font-medium text-brand-primary transition-all duration-200 hover:bg-brand-primary/20"
                >
                  View Resource
                </Link>
              </article>
            ))
          ) : (
            <div className="col-span-full rounded-xl border border-glass bg-bg-surface/40 p-10 text-center backdrop-blur-sm">
              <p className="text-text-secondary">No resources uploaded yet. Be the first to share!</p>
            </div>
          )}
        </div>
      </section>

      <section className="mx-auto w-full max-w-[1200px] px-[24px] pb-12">
        <div className="mb-6">
          <h2 className="text-[14px] font-semibold uppercase tracking-wider text-text-secondary">Top Contributors</h2>
          <p className="mt-2 text-sm text-text-muted">Most active student uploaders on the platform.</p>
        </div>

        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {topContributors.length > 0 ? (
            topContributors.map((creator) => (
              <article
                key={creator.uid}
                className="flex min-h-[180px] flex-col rounded-xl border border-glass bg-bg-surface/60 p-6 backdrop-blur-sm transition-all duration-200 hover:border-brand-violet/50 hover:shadow-[0_8px_40px_rgba(160,120,255,0.25)] hover:-translate-y-1"
              >
                <h3 className="text-lg font-semibold text-text-primary">{creator.name}</h3>

                <div className="mt-4 inline-flex items-center gap-1.5 text-sm text-text-secondary">
                  <Star className="text-brand-violet" size={16} fill="currentColor" aria-hidden="true" />
                  {creator.rating}
                </div>

                <div className="mt-auto flex flex-col gap-2 pt-5 text-sm text-text-muted">
                  <span>{creator.noteCount} resources</span>
                  <span>{creator.downloadSum} total downloads</span>
                </div>
              </article>
            ))
          ) : (
            <div className="col-span-full rounded-xl border border-glass bg-bg-surface/40 p-10 text-center backdrop-blur-sm">
              <p className="text-text-secondary">No contributors yet.</p>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}

export default App;
